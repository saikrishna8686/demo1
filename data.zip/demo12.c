demo12()
{

	return 0;
}